<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Sign In</name>
   <tag></tag>
   <elementGuidId>98df67e2-3171-422a-80c2-fb55516394e8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[2]/button[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>9df66120-3423-4d06-ad6e-35ef86abf116</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign In</value>
      <webElementGuid>94a2e1eb-d48d-4515-bd20-205b3e34355a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;min-h-screen flex flex-col&quot;]/div[@class=&quot;bg-mainColor-200 text-white flex justify-center&quot;]/div[@class=&quot;container p-3 flex justify-between items-center px-10&quot;]/div[@class=&quot;flex gap-4 mr-4&quot;]/button[@class=&quot;ant-btn css-dev-only-do-not-override-1i9hs8u ant-btn-default&quot;]/span[1]</value>
      <webElementGuid>7fe8b5bd-653e-49c6-ace2-88ccbe8be18d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[2]/button[2]/span</value>
      <webElementGuid>8630ddf6-c777-4213-9c0a-a7ea5745366e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up'])[1]/following::span[1]</value>
      <webElementGuid>5ceed536-c459-43cf-93e3-41b02641c085</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Booking Hotel'])[2]/following::span[2]</value>
      <webElementGuid>f5b235b5-c5b5-498a-9719-f0ccb5362e7e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find a hotel'])[1]/preceding::span[1]</value>
      <webElementGuid>44f9f9e1-e979-4853-8298-f93ab97a7a17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find a hotel easily anywhere'])[1]/preceding::span[1]</value>
      <webElementGuid>9bcb62ac-8a96-46c2-a6d7-53d4dfc72288</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign In']/parent::*</value>
      <webElementGuid>4be8f24e-83f5-444d-ba26-f2809758145b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[2]/span</value>
      <webElementGuid>123d97ac-b657-4a4c-b1d3-99e0e71ac3f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Sign In' or . = 'Sign In')]</value>
      <webElementGuid>02bd8289-09f5-4690-9499-47ea11278245</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
