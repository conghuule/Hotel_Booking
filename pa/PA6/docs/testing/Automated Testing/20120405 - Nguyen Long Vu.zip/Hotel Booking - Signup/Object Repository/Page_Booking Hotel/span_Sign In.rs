<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Sign In</name>
   <tag></tag>
   <elementGuidId>5b80fb21-b669-4207-a2d8-a08a80701032</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>bb80bc00-6d71-4be3-8cd6-770fb9ca7a83</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign In</value>
      <webElementGuid>3407ac8c-66fd-4b2b-b4ff-2b39e9eb757b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;min-h-screen flex flex-col&quot;]/div[@class=&quot;bg-mainColor-200 text-white flex justify-center&quot;]/div[@class=&quot;container p-3 flex justify-between items-center px-10&quot;]/div[@class=&quot;flex gap-4 mr-4&quot;]/button[@class=&quot;ant-btn css-dev-only-do-not-override-izhxqj ant-btn-default&quot;]/span[1]</value>
      <webElementGuid>a830ab41-ce50-4290-bbd3-40e3059732d8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[2]/button[2]/span</value>
      <webElementGuid>bdfc5a4f-9610-4e36-88ca-b22760763ccb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up'])[1]/following::span[1]</value>
      <webElementGuid>239849aa-7ed8-4b0f-9039-84a4b3a30c73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Booking Hotel'])[2]/following::span[2]</value>
      <webElementGuid>740d0902-bd5b-44dd-a5b6-6f2ba9677be5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find a hotel'])[1]/preceding::span[1]</value>
      <webElementGuid>7b2e2bc4-ef0a-4667-9c15-783325c4776a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find a hotel easily anywhere'])[1]/preceding::span[1]</value>
      <webElementGuid>956a03a7-a560-467e-9bf3-cf9bbfbe14cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign In']/parent::*</value>
      <webElementGuid>948c4770-2799-4d31-9aa0-c23f4fecec97</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[2]/span</value>
      <webElementGuid>ce5e22ee-f853-48a6-9926-4082f8b3786f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Sign In' or . = 'Sign In')]</value>
      <webElementGuid>508edb4d-3bb7-4c66-8c4c-9101da0080f9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
