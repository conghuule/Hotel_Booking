<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_I have read  agree with terms  conditions</name>
   <tag></tag>
   <elementGuidId>fb5414d3-1666-4456-a27b-16447362840e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='signupForm']/div[7]/div/div/div/div/label/span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>a84627f5-a256-4fa2-b895-d7f0bdfd5047</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>I have read &amp; agree with terms &amp; conditions</value>
      <webElementGuid>85027462-7bb8-4620-ba48-f276370315b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;signupForm&quot;)/div[@class=&quot;ant-form-item mb-5 css-dev-only-do-not-override-izhxqj&quot;]/div[@class=&quot;ant-row ant-form-item-row css-dev-only-do-not-override-izhxqj&quot;]/div[@class=&quot;ant-col ant-form-item-control css-dev-only-do-not-override-izhxqj&quot;]/div[@class=&quot;ant-form-item-control-input&quot;]/div[@class=&quot;ant-form-item-control-input-content&quot;]/label[@class=&quot;ant-checkbox-wrapper ant-checkbox-wrapper-in-form-item css-dev-only-do-not-override-izhxqj&quot;]/span[2]</value>
      <webElementGuid>08d932be-7ecb-469e-85df-9784f2f76a26</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='signupForm']/div[7]/div/div/div/div/label/span[2]</value>
      <webElementGuid>e0353feb-f8f4-41e1-871a-8a38878e63d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hotel Owner'])[1]/following::span[3]</value>
      <webElementGuid>89bc28c8-ae1c-404c-9fd6-7394f51aa8f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Customer'])[1]/following::span[6]</value>
      <webElementGuid>a6081b3f-3722-4d1c-83a2-88c5c928ace4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up'])[3]/preceding::span[1]</value>
      <webElementGuid>4592c0da-1558-49bc-9a57-b414c04a1a1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Copyright BookingHotel by AISE'])[1]/preceding::span[2]</value>
      <webElementGuid>eea12e20-7b1b-4e32-9b4b-d84268e07649</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='I have read &amp; agree with terms &amp; conditions']/parent::*</value>
      <webElementGuid>9062a542-c13f-47a2-be4c-32c5de57fdb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div/label/span[2]</value>
      <webElementGuid>178555c0-2cb0-45ab-bffe-7dda00af9b0d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'I have read &amp; agree with terms &amp; conditions' or . = 'I have read &amp; agree with terms &amp; conditions')]</value>
      <webElementGuid>22f26c41-02e2-4525-b1c2-0fcc1a15ca26</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
