<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Sign Up</name>
   <tag></tag>
   <elementGuidId>ebdaa295-a6e6-4ef7-9e8e-95fda05ad39a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.ant-btn.css-dev-only-do-not-override-izhxqj.ant-btn-default > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[2]/button/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>079be131-7ab5-4757-b3f6-a192597e59c2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign Up</value>
      <webElementGuid>ea19be8a-e71e-462b-b525-a72eccfef308</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;min-h-screen flex flex-col&quot;]/div[@class=&quot;bg-mainColor-200 text-white flex justify-center&quot;]/div[@class=&quot;container p-3 flex justify-between items-center px-10&quot;]/div[@class=&quot;flex gap-4 mr-4&quot;]/button[@class=&quot;ant-btn css-dev-only-do-not-override-izhxqj ant-btn-default&quot;]/span[1]</value>
      <webElementGuid>3d1fb76f-90af-4478-8397-03fea58c4dba</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[2]/button/span</value>
      <webElementGuid>1dd20c35-2e64-4e7a-8d7b-9ba89cbc561a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Booking Hotel'])[2]/following::span[1]</value>
      <webElementGuid>e18adb2c-1500-4c9c-959a-1dfa11c83214</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[1]/preceding::span[1]</value>
      <webElementGuid>bc7cf90d-ca27-4dde-8054-caa2bda8ce99</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find a hotel'])[1]/preceding::span[2]</value>
      <webElementGuid>bb4d9c5a-9efc-4b61-b7af-ca18a28560b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign Up']/parent::*</value>
      <webElementGuid>a131909d-70f5-4db6-bdec-45ea23c5b798</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button/span</value>
      <webElementGuid>72ae46bb-2804-4067-af16-08ebeff7a80d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Sign Up' or . = 'Sign Up')]</value>
      <webElementGuid>fa7d1b4f-0ede-43c3-9b83-d9ec4b146a0a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
