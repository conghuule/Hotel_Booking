<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Sign In</name>
   <tag></tag>
   <elementGuidId>26c0bf8c-cff8-48ce-88aa-ce948fa73ead</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[2]/button[2]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>385b775d-4551-4b41-b2c6-7199db30c31c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Sign In</value>
      <webElementGuid>2d8fd3fd-06e5-4096-a35d-508250386714</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;min-h-screen flex flex-col&quot;]/div[@class=&quot;bg-mainColor-200 text-white flex justify-center&quot;]/div[@class=&quot;container p-3 flex justify-between items-center px-10&quot;]/div[@class=&quot;flex gap-4 mr-4&quot;]/button[@class=&quot;ant-btn css-dev-only-do-not-override-hf4r1s ant-btn-default&quot;]/span[1]</value>
      <webElementGuid>a030eb79-e43a-422d-9127-f8ddc784f79c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[2]/button[2]/span</value>
      <webElementGuid>c99fcb23-a471-41af-8c1d-426c536b391e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up'])[1]/following::span[1]</value>
      <webElementGuid>b1375c02-80f8-47c0-a19e-22c7d312380a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Booking Hotel'])[2]/following::span[2]</value>
      <webElementGuid>a03bc580-ae9e-470f-9da1-2753e598ee51</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find a hotel'])[1]/preceding::span[1]</value>
      <webElementGuid>72bfc22a-d050-43e0-9852-7c0204800562</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find a hotel easily anywhere'])[1]/preceding::span[1]</value>
      <webElementGuid>7f772f3f-634e-44a9-9c32-235404367123</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Sign In']/parent::*</value>
      <webElementGuid>596af47b-5412-4d6b-bbec-6f4d441bb9b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[2]/span</value>
      <webElementGuid>f2bd5cdf-9215-4591-b5a2-fdf2b08bbcd8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Sign In' or . = 'Sign In')]</value>
      <webElementGuid>e2e34b1d-f114-477e-bd6c-329c58d02969</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
