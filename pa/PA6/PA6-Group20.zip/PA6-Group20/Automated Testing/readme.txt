Link youtube automated testing:
+ 20120294 - Lê Công Hửu:  https://youtu.be/b9hk0RRRBbs
+ 20120312 - Lê Tấn Kiệt: https://youtu.be/Z2cYLvSl8MI
+ 20120325 - Ngô Thanh Lực: https://youtu.be/0y1LVW9ThSs
+ 20120405 - Nguyễn Long Vũ: https://youtu.be/o0QKIOwhqzc
+ 20120422 - Nguyễn Thị Ánh Tuyết: https://youtu.be/Gg6fbwfMK5M