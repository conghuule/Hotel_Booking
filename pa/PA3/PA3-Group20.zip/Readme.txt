Trello: https://trello.com/invite/group20introse/ATTI1befbe407b2dc0055be244b45bb661e051F58379
Slack (14/11/2022; This link will be expried in 25 days): https://join.slack.com/t/group20-aise/shared_invite/zt-1jqjamcow-nFzIJu7kWN1Oo_ajDPdSgA
Github: https://github.com/ngothanhluc/Booking-Hotel-AISE